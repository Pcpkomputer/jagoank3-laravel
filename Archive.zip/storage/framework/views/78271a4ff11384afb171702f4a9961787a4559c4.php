<nav id="sidebarMenu" style="overflow:auto;padding-bottom:25px" class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
      <div class="position-sticky pt-3">
        <ul class="nav flex-column">
          <li class="nav-item">
            <a class="nav-link <?php echo e($selected=='dashboard' ? 'active':''); ?>" aria-current="page" href="<?php echo e(url('/admin/dashboard')); ?>">
              <span data-feather="home"></span>
              Dashboard
            </a>
          </li>
          <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
            <span>Data Training</span>
        </h6>
        <li class="nav-item">
            <a class="nav-link <?php echo e($selected=='training' ? 'active':''); ?>" href="<?php echo e(url('/admin/training')); ?>">
              <span data-feather="file-text"></span>
              Training
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link <?php echo e(($selected=='kategoritraining' ? 'active':'')); ?>" href="<?php echo e(url('/admin/kategoritraining')); ?>">
              <span data-feather="file-text"></span>
              Kategori Training
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link <?php echo e(($selected=='vouchertraining' ? 'active':'')); ?>" href="<?php echo e(url('/admin/vouchertraining')); ?>">
              <span data-feather="file-text"></span>
              Voucher Training
            </a>
          </li>
          <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
            <span>Data Master</span>
        </h6>
        <li class="nav-item">
            <a class="nav-link <?php echo e($selected==='instruktur' ? 'active':''); ?>" href="<?php echo e(url('/admin/instruktur')); ?>">
              <span data-feather="file-text"></span>
              Instruktur
            </a>
          </li> 
          <li class="nav-item">
            <a class="nav-link <?php echo e($selected==='shop' ? 'active':''); ?>" href="<?php echo e(url('/admin/shop')); ?>">
              <span data-feather="file-text"></span>
              Shop
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link <?php echo e(($selected=='galeri' ? 'active':'')); ?>" href="<?php echo e(url('/admin/galeri')); ?>">
              <span data-feather="file-text"></span>
              Galeri
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link <?php echo e(($selected=='artikel') ? 'active':''); ?>" href="<?php echo e(url('/admin/artikel')); ?>">
              <span data-feather="file-text"></span>
              Artikel
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link <?php echo e(($selected=='webinar') ? 'active':''); ?>" href="<?php echo e(url('/admin/webinar')); ?>">
              <span data-feather="file-text"></span>
              Webinar
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link <?php echo e(($selected=='ebook') ? 'active':''); ?>" href="<?php echo e(url('/admin/ebook')); ?>">
              <span data-feather="file-text"></span>
              E-book
            </a>
          </li>

          <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
            <span>Data Account</span>
        </h6>
        <li class="nav-item">
            <a class="nav-link <?php echo e(($selected=='user') ? 'active':''); ?>" href="<?php echo e(url('/admin/user')); ?>">
              <span data-feather="file-text"></span>
              User
            </a>
          </li>




          <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
            <span>Data Reports</span>
        </h6>
        <li class="nav-item">
            <a class="nav-link <?php echo e(($selected=='invoicetraining') ? 'active':''); ?>" href="<?php echo e(url('/admin/invoicetraining')); ?>">
              <span data-feather="file-text"></span>
              Invoice Training
            </a>
          </li>

          <li class="nav-item">
            <a class="nav-link <?php echo e(($selected=='invoiceshop') ? 'active':''); ?>" href="<?php echo e(url('/admin/invoiceshop')); ?>">
              <span data-feather="file-text"></span>
              Invoice Shop
            </a>
          </li>


          <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
            <span>Data Extra</span>
        </h6>
        <li class="nav-item">
        <a class="nav-link <?php echo e(($selected=='tentangjagoank3' ? 'active':'')); ?>" href="<?php echo e(url('/admin/tentangjagoank3')); ?>">
              <span data-feather="file-text"></span>
              Tentang Jagoan K3
            </a>
            <a class="nav-link <?php echo e(($selected=='banner' ? 'active':'')); ?>" href="<?php echo e(url('/admin/banner')); ?>">
              <span data-feather="file-text"></span>
              Banner
            </a>
            <a class="nav-link <?php echo e(($selected=='dashboardtext' ? 'active':'')); ?>" href="<?php echo e(url('/admin/dashboardtext')); ?>">
              <span data-feather="file-text"></span>
              Dashboard Text
            </a>
            <a class="nav-link <?php echo e(($selected=='ourclient' ? 'active':'')); ?>" href="<?php echo e(url('/admin/ourclient')); ?>">
              <span data-feather="file-text"></span>
              Our Client
            </a>
          </li>



          <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
            <span>Data Footer</span>
        </h6>

        <li class="nav-item">
            <a class="nav-link <?php echo e(($selected=='hubungikami' ? 'active':'')); ?>" href="<?php echo e(url('/admin/hubungikami')); ?>">
              <span data-feather="file-text"></span>
              Hubungi Kami
            </a>
            <a class="nav-link <?php echo e(($selected=='alamatkami' ? 'active':'')); ?>" href="<?php echo e(url('/admin/alamatkami')); ?>">
              <span data-feather="file-text"></span>
              Alamat Kami
            </a>
          </li>



          <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
            <span>Data Bantuan</span>
        </h6>

        <li class="nav-item">
            <a class="nav-link <?php echo e(($selected=='halamanbantuan' ? 'active':'')); ?>" href="<?php echo e(url('/admin/halamanbantuan')); ?>">
              <span data-feather="file-text"></span>
              Halaman Bantuan
            </a>
    
        <!-- <li class="nav-item">
            <a class="nav-link" href="#">
              <span data-feather="file"></span>
              Orders
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">
              <span data-feather="shopping-cart"></span>
              Products
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">
              <span data-feather="users"></span>
              Customers
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">
              <span data-feather="bar-chart-2"></span>
              Reports
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">
              <span data-feather="layers"></span>
              Integrations
            </a>
          </li> -->
        </ul>
<!-- 
        <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
          <span>Saved reports</span>
          <a class="link-secondary" href="#" aria-label="Add a new report">
            <span data-feather="plus-circle"></span>
          </a>
        </h6>
        <ul class="nav flex-column mb-2">
          <li class="nav-item">
            <a class="nav-link" href="#">
              <span data-feather="file-text"></span>
              Current month
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">
              <span data-feather="file-text"></span>
              Last quarter
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">
              <span data-feather="file-text"></span>
              Social engagement
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">
              <span data-feather="file-text"></span>
              Year-end sale
            </a>
          </li> -->
        </ul>
      </div>
    </nav><?php /**PATH /Users/yudhacode/Desktop/jagoank3-laravel/resources/views/Components/sidebar.blade.php ENDPATH**/ ?>